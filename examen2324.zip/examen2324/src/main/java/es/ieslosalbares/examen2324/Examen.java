/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package es.ieslosalbares.examen2324;

/**
 *
 * @author JOAQUIN RIOS
 */
public class Examen {

    /* Método que recibe el resultado de los dos partidos de una Final Four
        siendo 1->ganado y 0->perdido y devuelve en que posicion ha queda el 
        dependiendo del resultado de los dos partidos
     */
    public String finalFour(int partido1, int partido2) {
        String posicion = "error";
        if (partido1 == 1 && partido2 == 1) {
            posicion = "Campeón";
        }
        if (partido1 == 1 && partido2 == 0) {
            posicion = "Subcampeón";
        }
        if (partido1 == 0 && partido2 == 0) {
            posicion = "Tercero";
        }
        if (partido1 == 0 && partido2 == 1) {
            posicion = "Cuarto";
        }
        return posicion;
    }

    /* Método que devuelve true si un número es capicua 
       y false si no lo es */
    public boolean numeroCapicua(int numero) {

        int faltante;
        int numeroInvertido;
        int restante;

        faltante = numero;
        numeroInvertido = 0;

        while (faltante != 0) {
            restante = faltante % 10;
            numeroInvertido = numeroInvertido * 10 + restante;
            faltante = faltante / 10;
        }

        return numeroInvertido == numero;

    }

    /* Método que devuelve la primera cifra de un número entero
    /* Se permiten números de hasta 5 cifras.    */
    public int primerNumero(int n) {
        int primera = 0;

        if (n < 10) {
            primera = n;
        }

        if ((n >= 10) && (n < 100)) {
            primera = n / 10;
        }

        if ((n >= 100) && (n < 100)) {
            primera = n / 100;
        }

        if ((n >= 1000) && (n < 10000)) {
            primera = n / 1000;
        }

        if (n >= 10000) {
            primera = n / 10000;
        }

        return primera;
    }

    /* Escribe un programa que calcule el precio final de un producto según su
    base imponible (precio antes de impuestos), el tipo de IVA aplicado (general,
    reducido o superreducido) y el código promocional. Los tipos de IVA general,
    reducido y superreducido son del 21%, 10% y 4% respectivamente. Los códigos
    promocionales pueden ser nopro, mitad, meno5 o 5porc que significan
    respectivamente que no se aplica promoción, el precio se reduce a la mitad,
    se descuentan 5 euros o se descuenta el 5%.*/
    public static double precioFinal(double baseImponible, String tipoIVA, String codigoPromocional) {

        // Calcula el IVA y el precio antes del descuento
        int tipoIVANumerico = 0;

        switch (tipoIVA) {
            case "general" -> tipoIVANumerico = 21;
            case "reducido" -> tipoIVANumerico = 10;
            case "superreducido" -> tipoIVANumerico = 4;
            default -> System.out.println("El tipo de IVA introducido no es correcto.");
        }

        double iva = baseImponible * tipoIVANumerico / 100;
        double precioSinDescuento = baseImponible + iva;

        // Calcula el descuento
        double descuento = 0;

        switch (codigoPromocional) {
            case "nopro" -> {
            }
            case "mitad" -> // el precio se reduce a la mitad
                descuento = precioSinDescuento / 2;
            case "meno5" -> // se descuentan 5 euros
                descuento = descuento - 5;
            case "5porc" -> // se descuenta el 5%
                descuento = precioSinDescuento * 0.05;
            default -> System.out.println("El código promocional introducido no es correcto.");
        }

        // devuelve el precio final del producto desglosado
        return precioSinDescuento - descuento;
        
    }

}
