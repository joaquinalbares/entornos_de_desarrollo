/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package es.ieslosalbares.examen2324;

/**
 *
 * @author JOAQUIN RIOS
 */
public class Examen {

    /* Método que recibe el resultado de los dos partidos de una Final Four
        siendo 1->ganado y 0->perdido y devuelve en que posicion ha queda el 
        dependiendo del resultado de los dos partidos
     */
    public String finalFour(int partido1, int partido2) {
        String posicion = "error";
        if (partido1 == 1 && partido2 == 1) {
            posicion = "Campeón";
        }
        if (partido1 == 1 && partido2 == 0) {
            posicion = "Subcampeón";
        }
        if (partido1 == 0 && partido2 == 0) {
            posicion = "Tercero";
        }
        if (partido1 == 0 && partido2 == 1) {
            posicion = "Cuarto";
        }
        return posicion;
    }

    /* Método que devuelve true si un número es capicua 
       y false si no lo es */
    public boolean numeroCapicua(int numero) {

        int faltante;
        int numeroInvertido;
        int restante;

        faltante = numero;
        numeroInvertido = 0;

        while (faltante != 0) {
            restante = faltante % 10;
            numeroInvertido = numeroInvertido * 10 + restante;
            faltante = faltante / 10;
        }

        return numeroInvertido == numero;

    }

    /* Método que devuelve la primera cifra de un número entero
    /* Se permiten números de hasta 5 cifras.    */
    public int primerNumero(int n) {
        int primera = 0;

        if (n < 10) {
            primera = n;
        }

        if ((n >= 10) && (n < 100)) {
            primera = n / 10;
        }

        if ((n >= 100) && (n < 100)) {
            primera = n / 100;
        }

        if ((n >= 1000) && (n < 10000)) {
            primera = n / 1000;
        }

        if (n >= 10000) {
            primera = n / 10000;
        }

        return primera;
    }
    
    /* Implementa el juego piedra, papel y tijera.
     recibe como parámetros la jugada del jugador1 y la del jugador2 y devuelve un String 
    con el valor del ganador o Empate si ambos enseñan lo mismo*/
    public String piedraPapelTijera(String jugador1, String jugador2) {

        String devuelve;

        if (jugador1.equals(jugador2)) {
            devuelve = "Empate";
        } else {
            devuelve = "jugador2";
            switch (jugador1) {
                case "piedra" -> {
                    if (jugador2.equals("tijera")) {
                        devuelve = "jugador1";
                    }
                }
                case "papel" -> {
                    if (jugador2.equals("piedra")) {
                        devuelve = "jugador2";
                    }
                }
                case "tijera" -> {
                    if (jugador2.equals("papel")) {
                        devuelve = "jugador1";
                    }
                }
                default -> {
                }
            }
        }
        return devuelve;
    }

}
