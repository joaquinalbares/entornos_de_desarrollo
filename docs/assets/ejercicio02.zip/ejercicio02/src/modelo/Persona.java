/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.time.LocalDate;

/**
 *
 * @author joaquin
 */
public class Persona {
    private final String nombre;
    //he cambiado el nombre a apellido
    //he generado getter y setter
    private String apellido; 
    //he generado getter y setter
    private int numTelefono;
    //he generado getter y setter
    private String email;
    private LocalDate fechaNacimiento;
    private boolean escumpleanyos;
        
    // He creado el constructor con el nombre de parametro que habia en el Main
    public Persona(String nombre) {
        this.nombre = nombre;        
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public int getNumTelefono() {
        return numTelefono;
    }

    public void setNumTelefono(int numTelefono) {
        this.numTelefono = numTelefono;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }   


    public String getNombre() {
        return nombre;
    }

   
    public LocalDate getFechaNacimiento() {
        return fechaNacimiento;
    }
    public void setFechaNacimiento(LocalDate fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }
    
    public void compruebacumple () {
        LocalDate hoy = LocalDate.now();
        if (hoy.getDayOfMonth()==getFechaNacimiento().getDayOfMonth() &&
        hoy.getMonthValue()==getFechaNacimiento().getMonthValue()) {
            escumpleanyos = true;
        }
        else {
            escumpleanyos = false;
        }
    }
    
}
