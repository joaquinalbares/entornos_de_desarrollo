// He añadido el archivo al package correspondiente
package ejercicio02;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

// He creado el package modelo y la clase Persona
import modelo.Persona;

//He cambiado el nombre del archivo a App
public class App {
    public static void main(String[] args) throws Exception {
        //He cambiado el nombre a fecha
        LocalDate fecha = LocalDate.now();
        System.out.println(fecha.getDayOfMonth());
        System.out.println(fecha.getMonthValue());

        var pepe = new Persona("pepe");
        //Creamos un objeto tipo localdate
        var date = LocalDate.parse("2005-11-12");
        pepe.setFechaNacimiento(date);
        

    }
}


