/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package es.ieslosalbares.ejemplo;

/**
 *
 * @author joaquinrios
 */
public class Ejemplo {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
