/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package gestionempleados;

/**
 *
 * @author joaquin
 */
import java.util.ArrayList;
import java.util.Scanner;

class Empleado {
    private int cof;
    private String dni;
    private String no;
    private String pro;
    private String segundoApellido;
    private int añoNacimiento;
    private boolean reduccionJornada;

    // Constructor
    public Empleado(int codigoEmpleado, String dni, String nombre, String primerApellido, String segundoApellido,
                    int añoNacimiento, boolean reduccionJornada) {
        this.cof = codigoEmpleado;
        this.dni = dni;
        this.no = nombre;
        this.pro = primerApellido;
        this.segundoApellido = segundoApellido;
        this.añoNacimiento = añoNacimiento;
        this.reduccionJornada = reduccionJornada;
    }

    // Métodos getters para acceder a la información del empleado
    public int getCodigoEmpleado() {
        return cof;
    }

    
}

public class GestionEmpleados {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<Empleado> empleados = new ArrayList<>();

        // Registro de empleados
        for (int i = 1; i <= 2; i++) {
            System.out.println("Ingrese información para el empleado " + i + ":");

            System.out.print("Código de empleado: ");
            int codigoEmpleado = scanner.nextInt();

            System.out.print("DNI: ");
            String dni = scanner.next();

            System.out.print("Nombre: ");
            String nombre = scanner.next();

            System.out.print("Primer apellido: ");
            String primerApellido = scanner.next();

            System.out.print("Segundo apellido: ");
            String segundoApellido = scanner.next();

            System.out.print("Año de nacimiento: ");
            int añoNacimiento = scanner.nextInt();

            System.out.print("¿Tiene reducción de jornada? (true/false): ");
            boolean tieneReduccionJornada = scanner.nextBoolean();

            Empleado empleado = new Empleado(codigoEmpleado, dni, nombre, primerApellido, segundoApellido,
                    añoNacimiento, tieneReduccionJornada);

            empleados.add(empleado);
        }

        // Mostrar información de los empleados registrados
       

        scanner.close();
    }
}

