/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package es.ieslosalbares.ejemplo;

/**
 *
 * @author joaquinrios
 */
public class ExamenEjemplo {

    public String media(Double nota1, Double nota2, Double nota3) {

        double media = (nota1 + nota2 + nota3) / 3;

        if (media < 5) {
            return "Insuficiente";
        }

        if ((media >= 5) && (media < 6)) {
            return ("Suficiente");
        }

        if ((media >= 7) && (media < 6)) {
            return ("Bien");
        }

        if ((media >= 7) && (media < 9)) {
            return ("Notable");
        }

        if (media >= 9) {
            return ("Sobresaliente");
        }
        return "error";
    }

}
