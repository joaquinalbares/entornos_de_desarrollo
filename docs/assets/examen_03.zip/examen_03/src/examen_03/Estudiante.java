public class Estudiante {
	
	//Cada Estudiante tiene 5 asignaturas
	private Asi[] asignaturas = new Asignatura[5];
	private String nombre;
	
	public Estudiante(String nombre) {
		this.nombre = nombre;
	}
	
	public String getNombre() {
		return nombre;
	}
	
	/*
	 * Registra una Asignatura en la posicion del array que
	 * se le indique
	 */
	public void registrarAsignatura(Asignatura asign, int posicion) {
		asignaturas[posicion] = asign;
	}
	
	/*
	 * Retorna la nota definitiva de la asignatura que se encuentra
	 * en la posicion del array indicada.
	 */
	public int getNotaDeAsignatura(int posicion) {
		return asignaturas[posicion].getNotaDefinitiva();
	}
	
	/*
	 * Hace un promedio general de todas las asignaturas
	 * de este estudiante
	 */
	public int getPromedioGeneral() {
		//Sumamos las notas definitivas de sus asignaturas
		int sumaNotas = 0;
		for (Asignatura asig: asignaturas)
			sumaNotas += asig.getNotaDefinitiva();
		//Retornamos el promedio
		return sumaNotas / 5;
	}

}